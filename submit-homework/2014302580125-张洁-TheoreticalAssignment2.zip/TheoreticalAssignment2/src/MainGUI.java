import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class MainGUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Begin();
		//frame.setLocationRelativeTo(null);	
	}

}

//ʵ�ֿ�ʼ����
class Begin extends JFrame {
	private BankDatabase bankDataBase = new BankDatabase();
	private Account account;
	public Begin(){
		JFrame p1=new JFrame();
		p1.setTitle("Welcome");
		p1.setBounds(400,200,550,300);
		p1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		p1.setLayout(null);
		p1.setVisible(true);
		JLabel l1=new JLabel("Welcome to ATM!");
		l1.setSize(100,20);
		l1.setLocation(50,20);
		JLabel l2=new JLabel("Please enter your account number:");
		l2.setSize(200,20);
		l2.setLocation(50,60);
		JTextField t1=new JTextField();
		t1.setSize(100,20);
		t1.setLocation(250,60);
		p1.add(t1);
		
		JLabel l3=new JLabel("Please enter your pin:");
		l3.setSize(200,20);
		l3.setLocation(50,100);
		JPasswordField jp=new JPasswordField(20);
		jp.setSize(100,20);
		jp.setLocation(180,100);
		p1.add(jp);
		
		p1.add(l1);
		p1.add(l2);
		p1.add(l3);
		Button button=new Button("OK");
		button.setSize(100,30);
		button.setLocation(150,150);
		p1.add(button);
		p1.repaint();
		button.addActionListener(new ActionListener(){
			
			public boolean userAuthenticated(){
				int userAccountNumber1=Integer.parseInt(t1.getText());
				int userPIN1=Integer.parseInt(new String(jp.getPassword()));
				boolean b=bankDataBase.authenticateUser(userAccountNumber1, userPIN1);
				if(b==true){
					account=bankDataBase.getAccount(userAccountNumber1);
				}
				return b;
			}

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(userAuthenticated()){
					p1.dispose();
					//new MainMenu();
					new MainMenu(bankDataBase,account);
				//System.out.print("ok");
				}
				else{
//					JLabel jl=new JLabel("Account number or pin is incorrect!");
//					jl.setSize(200,20);
//					jl.setLocation(200,200);
//					p1.add(jl);
					JOptionPane.showMessageDialog(p1,
							"Account number or pin is incorrect!");
					t1.setText("");
					jp.setText("");
				}
			}
		}
				);
	}
	
	}
//ʵ�����˵�����
class MainMenu extends JFrame{
	public MainMenu(BankDatabase bankDatabase,Account account){
		BankDatabase bdb=bankDatabase;
		Account acc=account;
	JFrame p2=new JFrame();
	p2.setTitle("MainMenu");
	p2.setBounds(400,200,550,300);
	p2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	p2.setLayout(null);
	p2.setVisible(true);
	JLabel l1=new JLabel("MainMenu:");
	l1.setSize(100,20);
	l1.setLocation(50,20);
	JLabel l2=new JLabel("1-View my balance");
	l2.setSize(200,20);
	l2.setLocation(50,60);
	JLabel l3=new JLabel("2-Withdraw cash");
	l3.setSize(200,20);
	l3.setLocation(50,100);
	JLabel l4=new JLabel("3-Deposit funds");
	l4.setSize(200,20);
	l4.setLocation(50,140);
	JLabel l5=new JLabel("4-Exit");
	l5.setSize(200,20);
	l5.setLocation(50,180);
	JLabel l6=new JLabel("Enter a choice:");
	l6.setSize(100,20);
	l6.setLocation(50,220);
	p2.add(l1);
	p2.add(l2);
	p2.add(l3);
	p2.add(l4);
	p2.add(l5);
	p2.add(l6);
	JTextField t1=new JTextField();
	t1.setSize(100,20);
	t1.setLocation(150,220);
	p2.add(t1);
	Button button=new Button("OK");
	button.setSize(100,30);
	button.setLocation(300,220);
	p2.add(button);
	p2.repaint();
	button.addActionListener(new ActionListener(){
		//int choice=Integer.parseInt(t1.getText());
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			int choice=Integer.parseInt(t1.getText());
			switch(choice){
			case 1:
				p2.dispose();
				new Balance(bdb,acc);break;
				//System.out.print("1");break;
			case 2:
				p2.dispose();
				new Withdraw(bdb,acc);break;
				//System.out.print("2");break;
			case 3:
				p2.dispose();
				new Depositt(bdb,acc);break;
				//System.out.print("3");break;
			case 4:
				System.exit(0);break;
			default:
				JOptionPane.showMessageDialog(p2,
					"Input Error!");
			t1.setText("");
			}
		}
		
	}
			);
	}
}
//ʵ��������
class Balance extends JFrame{
	//private Screen screen;
	public Balance(BankDatabase bankDatabase,Account account){
		BankDatabase bdb=bankDatabase;
		Account acc=account;
	JFrame p3=new JFrame();
	p3.setTitle("Balance");
	p3.setBounds(400,200,550,300);
	p3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	p3.setLayout(null);
	p3.setVisible(true);
	double availableBalance=bdb.getAvailableBalance(acc.getAccountNumber());
	JLabel l1=new JLabel("AvailableBalance:"+availableBalance);
	l1.setSize(200,20);
	l1.setLocation(50,60);
	p3.add(l1);
	double totalBalance=bdb.getTotalBalance(acc.getAccountNumber());
	JLabel l2=new JLabel("TotalBalance:"+totalBalance);
	l2.setSize(200,20);
	l2.setLocation(50,100);
	p3.add(l2);
	}
}
//ʵ��ȡ�����
class Withdraw extends JFrame{
	public Withdraw(BankDatabase bankDatabase,Account account){
		BankDatabase bdb=bankDatabase;
		Account acc=account;
		JFrame p4=new JFrame();
		p4.setTitle("Withdraw");
		p4.setBounds(400,200,550,300);
		p4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		p4.setLayout(null);
		p4.setVisible(true);
		
		JLabel l1=new JLabel("WithdrawalMenu:");
		l1.setSize(100,20);
		l1.setLocation(50,20);
		JLabel l2=new JLabel("1-$20");
		l2.setSize(100,20);
		l2.setLocation(50,60);
		JLabel l7=new JLabel("4-$100");
		l7.setSize(100,20);
		l7.setLocation(150,60);
		JLabel l3=new JLabel("2-$40");
		l3.setSize(100,20);
		l3.setLocation(50,100);
		JLabel l8=new JLabel("5-$200");
		l8.setSize(100,20);
		l8.setLocation(150,100);
		JLabel l4=new JLabel("3-$60");
		l4.setSize(100,20);
		l4.setLocation(50,140);
		JLabel l9=new JLabel("6-Cancel transaction");
		l9.setSize(200,20);
		l9.setLocation(150,140);
		JLabel l5=new JLabel("Choose a withdrawal amount:");
		l5.setSize(200,20);
		l5.setLocation(50,180);
//		JLabel l6=new JLabel("Enter a choice:");
//		l6.setSize(100,20);
//		l6.setLocation(50,220);
		p4.add(l1);
		p4.add(l2);
		p4.add(l3);
		p4.add(l4);
		p4.add(l5);
	//	p4.add(l6);
		p4.add(l7);
		p4.add(l8);
		p4.add(l9);
		JTextField t1=new JTextField();
		t1.setSize(100,20);
		t1.setLocation(250,180);
		p4.add(t1);
		Button button=new Button("OK");
		button.setSize(100,30);
		button.setLocation(400,180);
		p4.add(button);
		button.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				int choice=Integer.parseInt(t1.getText());
				double amount;
				switch(choice){
				case 1:
					amount=20;
					acc.debit(amount);
					JOptionPane.showMessageDialog(p4,
							"Successful operation!"+"\nTotalBalance:"+
					acc.getTotalBalance()+"\nAvailableBalance:"+acc.getAvailableBalance());
					break;
				case 2:
					amount=40;
					acc.debit(amount);
					JOptionPane.showMessageDialog(p4,
							"Successful operation!"+"\nTotalBalance:"+
					acc.getTotalBalance()+"\nAvailableBalance:"+acc.getAvailableBalance());
					break;
				case 3:
					amount=60;
					acc.debit(amount);
					JOptionPane.showMessageDialog(p4,
							"Successful operation!"+"\nTotalBalance:"+
					acc.getTotalBalance()+"\nAvailableBalance:"+acc.getAvailableBalance());
					break;
				case 4:
					amount=100;
					acc.debit(amount);
					JOptionPane.showMessageDialog(p4,
							"Successful operation!"+"\nTotalBalance:"+
					acc.getTotalBalance()+"\nAvailableBalance:"+acc.getAvailableBalance());
					break;
				case 5:
					amount=200;
					acc.debit(amount);
					JOptionPane.showMessageDialog(p4,
							"Successful operation!"+"\nTotalBalance:"+
					acc.getTotalBalance()+"\nAvailableBalance:"+acc.getAvailableBalance());
					break;
				case 6:
					System.exit(0);break;
					default:
						JOptionPane.showMessageDialog(p4,
								"Input Error!");
						t1.setText("");
				}
			}
			
		}
				);
	}
}

//ʵ�ִ�����
class Depositt extends JFrame{
	public Depositt(BankDatabase bankDatabase,Account account){
		BankDatabase bdb=bankDatabase;
		Account acc=account;
		JFrame p5=new JFrame();
		p5.setTitle("Deposit");
		p5.setBounds(400,200,550,300);
		p5.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		p5.setLayout(null);
		p5.setVisible(true);
		JLabel l1=new JLabel("Please input amount:");
		l1.setSize(200,20);
		l1.setLocation(50,60);
		JTextField t1=new JTextField();
		t1.setSize(100,20);
		t1.setLocation(250,60);
		p5.add(l1);
		p5.add(t1);
		Button button=new Button("OK");
		button.setSize(100,30);
		button.setLocation(400,60);
		p5.add(button);
		button.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				double amount=Double.parseDouble(t1.getText());
				//System.out.print(amount);
				acc.credit(amount);
				//System.out.print(acc.getTotalBalance());
//				double totalBalance=acc.getTotalBalance();
//				JLabel l2=new JLabel("Successful operation!");
//				l2.setSize(200,20);
//				l2.setLocation(50,100);
//				JLabel l3=new JLabel("TotalBalance:"+totalBalance);
//				l3.setSize(200,20);
//				l3.setLocation(50,120);
//				p5.add(l2);
//				p5.add(l3);
//				p5.repaint();
				JOptionPane.showMessageDialog(p5,
						"Successful operation!"+"\nTotalBalance:"+
				acc.getTotalBalance()+"\nAvailableBalance:"+acc.getAvailableBalance());
			}
			
		}
				);
	}
}