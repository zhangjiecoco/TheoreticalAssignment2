import java.awt.Button;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class ATMGUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Login();
	}

}

//Login��ʵ�ֵ�¼����
class Login {
	private JFrame jf;
	private JLabel jl;
	private JLabel jl2;
	private JLabel jl3;
	private JLabel jl4;
	private JTextField jt;
	private JPasswordField jp;
	private Button button;
	private BankDatabase dataBase = new BankDatabase();
	private Account account;
	public Login() {
		frameInit();
		label1Init();
		label2Init();
		accountNumberInit();
		passwordInit();
		buttonInit();
		keyInit();
		jf.setVisible(true);
	}
	private void frameInit() {
		jf = new JFrame("ATM");
		jf.setBounds(400, 200, 500, 350);
		jf.setLayout(null);
		jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
	private void label1Init()
	{
		jl = new JLabel("Welcome");
		jl.setSize(100, 20);
		jl.setLocation(50, 20);
		jf.add(jl);
	}
	private void label2Init()
	{
		jl2 = new JLabel(
				"Please enter your AccountNumber and PIN to login");
		jl2.setSize(400, 20);
		jl2.setLocation(50, 50);
		jf.add(jl2);
	}
	private void accountNumberInit()
	{
		jl3 = new JLabel("AccountNumber:");
		jl3.setSize(100, 30);
		jl3.setLocation(50, 115);
		jf.add(jl3);
		jt = new JTextField();
		jt.setSize(200, 20);
		jf.add(jt);
		jt.setLocation(160, 120);
	}
	private void passwordInit()
	{
		jl4 = new JLabel("PIN:");
		jl4.setSize(100, 30);
		jl4.setLocation(90, 163);
		jf.add(jl4);
		jp = new JPasswordField(20);
		jp.setSize(200, 20);
		jp.setLocation(160, 165);
		jf.add(jp);
	}
	private void buttonInit()
	{
		button = new Button("��¼");
		button.setSize(100, 30);
		button.setLocation(185, 240);
		button.addActionListener(new ActionListener() {

			public boolean userAuthenticated() {
				int userAccountNumber = Integer.parseInt(jt.getText());
				int userPIN = Integer.parseInt(new String(jp.getPassword()));
				if(dataBase.authenticateUser(userAccountNumber, userPIN))
					account=dataBase.getAccount(userAccountNumber);
				return dataBase.authenticateUser(userAccountNumber, userPIN);
			}

			@Override
			public void actionPerformed(ActionEvent e) {
				if (userAuthenticated()) {
					jf.dispose();
					jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
					new MainMenu(dataBase,account);
				} else {
					JOptionPane.showMessageDialog(jf,
							"Invalid account number or PIN. Please try again.");
					jt.setText("");
					jp.setText("");
				}
			}
		});
		jf.add(button);
	}
	
	//���ûس��¼����͵�����ť�¼�Ч����ͬ
	private void keyInit()
	{
		jp.addKeyListener(new KeyAdapter() {

			public boolean userAuthenticated() {
				int userAccountNumber = Integer.parseInt(jt.getText());
				int userPIN = Integer.parseInt(new String(jp.getPassword()));
				if(dataBase.authenticateUser(userAccountNumber, userPIN))
					account=dataBase.getAccount(userAccountNumber);
				return dataBase.authenticateUser(userAccountNumber, userPIN);
			}

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				int code = e.getKeyCode();
				if (code == KeyEvent.VK_ENTER) {
					if (userAuthenticated()) {
						jf.dispose();
						jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
						new MainMenu(dataBase,account);

					} else {
						JOptionPane
								.showMessageDialog(jf,
										"Invalid account number or PIN. Please try again.");
						jt.setText("");
						jp.setText("");
					}
				}
			}

		});
	}
}

//MainMenu��Ϊ���˵�
class MainMenu {
	private JScrollPane jsp;
	private JTextArea ja;
	private JFrame jf2;
	private JTextField jt;
	private Button button;
	private int choice = 0;
	private int currentAccountNumber;
	private Screen screen;
	private Keypad keypad;
	private CashDispenser cashDispenser=new CashDispenser(); // ATM's cash dispenser
	private DepositSlot depositSlot; // ATM's deposit slot
	private BankDatabase bankDatabase; // account information database
	// constants corresponding to main menu options
	private static final int BALANCE_INQUIRY = 1;
	private static final int WITHDRAWAL = 2;
	private static final int DEPOSIT = 3;
	private static final int EXIT = 4;
	
	private Transaction currentTransaction = null;

	
	public int getCurrentAccountNumber()
	{
		return currentAccountNumber;
	}
	public Transaction getTransaction()
	{
		return currentTransaction;
	}
	public CashDispenser getCashDispenser()
	{
		return cashDispenser;
	}
	
	public BankDatabase getBankDatabase()
	{
		return bankDatabase;
	}
	
	public MainMenu(BankDatabase bankDatabase,Account account) {
		this.bankDatabase = bankDatabase;
		this.currentAccountNumber=account.getAccountNumber();
		frameInit();
		textAreaInit();
		textFieldInit();
		buttonInit();
		jf2.setVisible(true);
		showMainMenu();
	}

	//��Frame���г�ʼ��
	private void frameInit()
	{
		jf2 = new JFrame();
		jf2.setBounds(400, 200, 500, 400);
		jf2.setLayout(null);
		jf2.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		
	}
	
	//��TextArea���г�ʼ��
	private void textAreaInit()
	{
		ja = new JTextArea();
		jsp=new JScrollPane(ja);
		jsp.setSize(500, 240);
		jsp.setLocation(0, 0);
		jf2.add(jsp);
		ja.setEditable(false);
		jsp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
	}

	//��TextField���г�ʼ��
	private void textFieldInit()
	{
		jt = new JTextField();
		jt.setSize(350, 25);
		jt.setLocation(15, 300);
		jt.setText("");
		jf2.add(jt);
		//���ûس��¼����͵�����ť�¼���ͬ
		jt.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) 
			{
				int code = e.getKeyCode();
				if (code == KeyEvent.VK_ENTER)
				{
					choice = Integer.parseInt(jt.getText());
					jt.setText("");
					transaction(choice);
					showMainMenu();
				}
			}
		});
	}
	
	//��button���г�ʼ��
	private void buttonInit()
	{
		button = new Button("Enter");
		button.setSize(50, 25);
		button.setLocation(400, 298);
		jf2.add(button);

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				choice = Integer.parseInt(jt.getText());
				jt.setText("");
				transaction(choice);
				showMainMenu();
			}

		});
	}
	
	//��TextArea����ʾ�˵�
	public void showMainMenu() {
		ja.append(System.lineSeparator()+"Main menu:");
		ja.append(System.lineSeparator() + "1 - View my balance");
		ja.append(System.lineSeparator() + "2 - Withdraw cash");
		ja.append(System.lineSeparator() + "3 - Deposit funds");
		ja.append(System.lineSeparator() + "4 - Exit");
		ja.append(System.lineSeparator() + "Enter a choice: ");
	}

	//�����û���ѡ���ṩ��ͬ�Ĺ���
	public void transaction(int choice) {
		// decide how to proceed based on user's menu selection
		switch (choice) {
		// user chose to perform one of three transaction types
		case BALANCE_INQUIRY:
			currentTransaction = createTransaction(choice);
			balanceInquiryExecute(currentTransaction);
			break;
		case WITHDRAWAL:
			currentTransaction=createTransaction(choice);
			withdrawalExecute();
			break;
		case DEPOSIT:
			currentTransaction = createTransaction(choice);
			depositExecute();
			break;
		case EXIT: // user chose to terminate session
			System.exit(0);
			break;
		default: // user did not enter an integer from 1-4
			ja.append(System.lineSeparator()
					+ "You did not enter a valid selection. Try again.");
			break;
		} // end switch
	} 

	private Transaction createTransaction(int type) {
		Transaction temp = null; // temporary Transaction variable
		switch (type) {
		case BALANCE_INQUIRY: // create new BalanceInquiry transaction
			temp = new BalanceInquiry(currentAccountNumber, screen,
					bankDatabase);
			break;
		case WITHDRAWAL: // create new Withdrawal transaction
			temp = new Withdrawal(currentAccountNumber, screen, bankDatabase,
					keypad, cashDispenser);
			break;
		case DEPOSIT: // create new Deposit transaction
			temp = new Deposit(currentAccountNumber, screen, bankDatabase,
					keypad, depositSlot);
			break;
		} // end

		return temp;
	}
	
	//���û�ѡ��Balanceʱִ�еĲ���
	private void balanceInquiryExecute(Transaction currentTransaction)
	{
		double availableBalance = bankDatabase
				.getAvailableBalance(currentTransaction.getAccountNumber());
		double totalBalance = bankDatabase.getTotalBalance(currentTransaction.getAccountNumber());
		ja.append(System.lineSeparator()+"Balance Information:");
		ja.append(System.lineSeparator()+" - Available balance: ");
		ja.append(System.lineSeparator()+availableBalance);
		ja.append(System.lineSeparator()+" - Total balance: ");
		ja.append(System.lineSeparator()+totalBalance);
		ja.append(System.lineSeparator());
		
		return;
	}
	
	//���û�ѡ��Withdraw Cashʱ���еĲ���
	private void withdrawalExecute()
	{
		new AmountsMenu(this);
	}
	
	//���û�ѡ��Deposit Fundsʱ���еĲ���
	private void depositExecute()
	{
		new DepositMoney(this);
	}
}

class AmountsMenu
{
	private JFrame jf;
	private JTextArea ja;
	private JScrollPane jsp;
	private Button button1;
	private Button button2;
	private Button button3;
	private Button button4;
	private Button button5;
	private Button button6;
	private int moneyChoice;
	private MainMenu mainMenu;
	private Transaction currentTransaction;
	private BankDatabase bankDatabase;
	private CashDispenser cashDispenser;
	private final static int CANCELED = 6;
	
	//AmountsMenu��ĳ�ʼ��
	public AmountsMenu(MainMenu mainMenu)
	{
		this.mainMenu=mainMenu;
		currentTransaction=mainMenu.getTransaction();
		bankDatabase=mainMenu.getBankDatabase();
		cashDispenser=mainMenu.getCashDispenser();
		frameInit();
		textAreaInit();
		button1Init();
		button2Init();
		button3Init();
		button4Init();
		button5Init();
		button6Init();
		amountMenu();
	}
	
	//��Frame���г�ʼ��
	private void frameInit()
	{
		jf=new JFrame();
		jf.setVisible(true);
		jf.setBounds(400, 200, 500, 400);
		jf.setLayout(null);
		jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
	
	//��TextArea���г�ʼ��
	private void textAreaInit()
	{
		ja=new JTextArea();
		jsp=new JScrollPane(ja);
		jsp.setSize(500, 240);
		jsp.setLocation(0, 0);
		jf.add(jsp);
		ja.setEditable(false);
		jsp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
	}
	
	//��������ť���г�ʼ��
	
	private void button1Init()
	{
		button1 = new Button("$20");
		button1.setSize(75, 35);
		button1.setLocation(70, 250);
		jf.add(button1);
		button1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				moneyChoice=1;
				execute();		//ͨ��Button�ĵ����¼���ʵ��ȡ���
			}
		});
	}
	
	private void button2Init()
	{
		button2 = new Button("$40");
		button2.setSize(75, 35);
		button2.setLocation(195, 250);
		jf.add(button2);
		button2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				moneyChoice=2;
				execute();
			}
		});
	}
	
	private void button3Init()
	{
		button3 = new Button("$60");
		button3.setSize(75, 35);
		button3.setLocation(320, 250);
		jf.add(button3);
		button3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				moneyChoice=3;
				execute();
			}
		});
	}
	
	private void button4Init()
	{
		button4 = new Button("$100");
		button4.setSize(75, 35);
		button4.setLocation(70, 298);
		jf.add(button4);
		button4.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				moneyChoice=4;
				execute();
			}
		});
	}
	
	private void button5Init()
	{
		button5 = new Button("$200");
		button5.setSize(75, 35);
		button5.setLocation(195, 298);
		jf.add(button5);
		button5.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				moneyChoice=5;
				execute();
			}
		});
	}
	
	private void button6Init()
	{
		button6 = new Button("Return");
		button6.setSize(75, 35);
		button6.setLocation(320, 298);
		jf.add(button6);
		button6.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				moneyChoice=6;
				execute();
				jf.dispose();		//���û�ѡ���˷��أ��رյ�ǰ���ڻص����˵�
			}
		});
	}
	
	//��TextArea����ʾ�˵�
	private void amountMenu()
	{
		ja.append(System.lineSeparator()+"Withdrawal Menu:");
		ja.append(System.lineSeparator()+"1 - $20");
		ja.append(System.lineSeparator()+"2 - $40");
		ja.append(System.lineSeparator()+"3 - $60");
		ja.append(System.lineSeparator()+"4 - $100");
		ja.append(System.lineSeparator()+"5 - $200");
		ja.append(System.lineSeparator()+"6 - Cancel transaction");
		ja.append(System.lineSeparator()+"Choose a withdrawal amount: ");
		
		return;
	}
	
	//execute����ʵ��ȡ���
	public void execute()
	{
		double availableBalance;
		int amount=displayMenuOfAmounts();;
		if (amount != CANCELED) {
			// get available balance of account involved
			availableBalance = bankDatabase
					.getAvailableBalance(currentTransaction.getAccountNumber());

			// check whether the user has enough money in the account
			if (amount <= availableBalance) {
				// check whether the cash dispenser has enough money
				if (cashDispenser.isSufficientCashAvailable(amount)) {
					// update the account involved to reflect the withdrawal
					bankDatabase.debit(currentTransaction.getAccountNumber(), amount);

					cashDispenser.dispenseCash(amount); // dispense cash
					// instruct user to take cash
					ja.append(System.lineSeparator()+"Your cash has been"
							+ " dispensed. Please take your cash now.");
				} // end if
				else
					// cash dispenser does not have enough cash
					ja.append(System.lineSeparator()+"Insufficient cash available in the ATM."
							+ System.lineSeparator()+System.lineSeparator()+"Please choose a smaller amount.");
			} // end if
			else // not enough money available in user's account
			{
				ja.append(System.lineSeparator()+"Insufficient funds in your account."
						+ System.lineSeparator()+System.lineSeparator()+"Please choose a smaller amount.");
			} // end else
		} // end if
		else // user chose cancel menu option
		{
			ja.append(System.lineSeparator()+"Canceling transaction...");
			return; // return to main menu because user canceled
		} // end else
	}

	private int displayMenuOfAmounts() {
		// TODO Auto-generated method stub
		int userChoice = 0; // local variable to store return value
		// array of amounts to correspond to menu numbers
		int[] amounts = { 0, 20, 40, 60, 100, 200 };
			// display the withdrawal menu
			// determine how to proceed based on the input value
			switch (moneyChoice) {
			case 1: // if the user chose a withdrawal amount
			case 2: // (i.e., chose option 1, 2, 3, 4 or 5), return the
			case 3: // corresponding amount from amounts array
			case 4:
			case 5:
				userChoice = amounts[moneyChoice]; // save user's choice
				break;
			case CANCELED: // the user chose to cancel
				userChoice = CANCELED; // save user's choice
				break;
			default: // the user did not enter a value from 1-6
				ja.append(System.lineSeparator()+"Invalid selection. Try again.");
			} // end switch

		return userChoice; // return withdrawal amount or CANCELED
	}

	
}
//DepositMoney��ʵ�ִ���
class DepositMoney
{
	private JFrame jf;
	private JTextField jt;
	private JTextArea ja;
	private JScrollPane jsp;
	private Button button1;
	private Button button2;
	private double money;
	private MainMenu mainMenu;
	private BankDatabase bankDatabase;
	private final static int CANCELED = 0;
	
	//DepositMoney��ĳ�ʼ��
	public DepositMoney(MainMenu mainMenu)
	{
		this.mainMenu=mainMenu;
		bankDatabase=mainMenu.getBankDatabase();
		frameInit();
		textAreaInit();
		textFieldInit();
		button1Init();
		button2Init();
		jf.setVisible(true);
		ja.append("Please enter a deposit amount in "+"CENTS (or 0 to cancel): ");
	}
	
	//��Frame���г�ʼ��
	private void frameInit()
	{
		jf=new JFrame();
		jf.setBounds(400, 200, 500, 400);
		jf.setLayout(null);
		jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
	
	//��TextArea���г�ʼ��
	private void textAreaInit()
	{
		ja=new JTextArea();
		jsp=new JScrollPane(ja);
		jsp.setSize(500, 240);
		jsp.setLocation(0, 0);
		jf.add(jsp);
		ja.setEditable(false);
		jsp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
	}
	
	//��TextField���г�ʼ��
	private void textFieldInit()
	{
		jt = new JTextField();
		jt.setSize(300, 25);
		jt.setLocation(15, 300);
		jt.setText("");
		jf.add(jt);
		jt.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e)
			{
				int code = e.getKeyCode();
				if (code == KeyEvent.VK_ENTER)
				{
					money = Double.parseDouble(jt.getText());
					money=(double)(money/100);
					jt.setText("");
					execute();
				}
			}
		});
	}
	
	//������Button��ť���г�ʼ��
	
	private void button1Init()
	{
		button1 = new Button("Enter");
		button1.setSize(50, 25);
		button1.setLocation(335, 298);
		jf.add(button1);

		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				money = Double.parseDouble(jt.getText());
				money=(double)(money/100);
				jt.setText("");
				execute();
			}

		});
	}
	
	private void button2Init()
	{
		button2=new Button("Return");
		button2.setSize(50,25);
		button2.setLocation(410,298);
		jf.add(button2);
		
		button2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				jf.dispose();
			}
		});
	}
	
	//execute����ʵ�ִ���
	private void execute()
	{
		// check whether user entered a deposit amount or canceled
		if (money != CANCELED) {
			// request deposit envelope containing specified amount
			ja.append(System.lineSeparator()+"Please insert a deposit envelope containing ");
			ja.append(money+"");
			ja.append(".");

			// receive deposit envelope

			// check whether deposit envelope was received
			ja.append(System.lineSeparator()+"Your envelope has been "
					+ "received."+System.lineSeparator()+"NOTE: The money just deposited will not "
					+ "be available until we verify the amount of"+System.lineSeparator()
					+ "              any enclosed cash and your checks clear.");
				// credit account to reflect the deposit
			bankDatabase.credit(mainMenu.getCurrentAccountNumber(), money);
		} // end if
		else // user canceled instead of entering amount
		{
			jf.dispose();
		} // end else
	}
	
}

//һЩ��������ֻ�����ֱ�ӵ�����ť���쳣���Ŵ��������Լ���ˮƽ���Ǵ�������ֻ�ܷ���....