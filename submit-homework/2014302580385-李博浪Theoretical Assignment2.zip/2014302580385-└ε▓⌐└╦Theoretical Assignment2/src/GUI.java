import java.awt.*;
import java.awt.event.ActionEvent;

import javax.swing.*;

public class GUI
{

	public static void main(String[] args)
	{
		// TODO �Զ����ɵķ������
		EventQueue.invokeLater(
				new Runnable()
				{
					public void run()
					{
						JFrame a=new ATMFrame();
						a.setTitle("atm");
						a.setVisible(true);
						a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					}
				});
	}

}
class ATMFrame extends JFrame
{
	private ATM atm;
	private static final int WIDTH=200;
	private static final int HEIGHT=200;
	
	//Panel
	private AccountInterface accountInterface;
	private SelectInterface selectInterface;
	private ViewInterface viewInterface;
	private WithdrawInterface withdrawInterface;
	private DepositInterface depositInterface;
	public ATMFrame()
	{
		setSize(WIDTH,HEIGHT);
		setLocation(100,100);
		
		atm=new ATM();
		accountInterface=new AccountInterface(this.atm);	
		selectInterface=new SelectInterface(this.atm);
		viewInterface=new ViewInterface(this.atm);
		withdrawInterface=new WithdrawInterface(this.atm);
		depositInterface=new DepositInterface(this.atm);
		
		accountInterface.setInterface(selectInterface);
		selectInterface.setView(viewInterface);
		selectInterface.setWithdraw(withdrawInterface);
		selectInterface.setDeposit(depositInterface);
		viewInterface.setSelect(selectInterface);
		withdrawInterface.setSelect(selectInterface);
		depositInterface.setSelect(selectInterface);
		
		add(accountInterface);
		add(selectInterface);
		add(viewInterface);
		add(withdrawInterface);
		add(depositInterface);
		
		accountInterface.setVisible(true);
		selectInterface.setVisible(false);
		viewInterface.setVisible(false);
		withdrawInterface.setVisible(false);
		depositInterface.setVisible(false);
		Image img=new ImageIcon("java.jpg").getImage();
		setIconImage(img);
		
		
	}
}

//�����˻�������
class AccountInterface extends JPanel
{
	private SelectInterface selectInterface;
	
	private ATM atm;
	private static final int WIDTH=200;
	private static final int HEIGHT=200;
	
	public JButton ensure; //ȷ�ϰ�ť
	public JTextField accountNumber;
	public JPasswordField accountPassword;
	public void setInterface(SelectInterface selectInterface)
	{
		this.selectInterface=selectInterface;
	}
	private class EnsureAction extends AbstractAction
	{
		@Override
		public void actionPerformed(ActionEvent e)
		{
			String account=accountNumber.getText().trim();
			String password=new String(accountPassword.getPassword());
			atm.run1(account, password);
			if(atm.getUserAuthenticated()==true)
			{
				AccountInterface.this.setVisible(false);
				selectInterface.setVisible(true);
			}
		}		
	}
	public AccountInterface(ATM atm)
	{
		this.atm=atm;
		this.setLayout(null);
		setSize(WIDTH,HEIGHT);
		//��ʼ����ť
		ensure=new JButton("ȷ��");
		accountNumber=new JTextField(10);
		accountPassword=new JPasswordField(10);	
		JLabel welcome=new JLabel("welcome");
		JLabel accountLabel=new JLabel("account:");
		JLabel passwordLabel=new JLabel("password:");
		
		//��������ӵ������
		add(welcome);
		welcome.setBounds(WIDTH/2-30,0,60,20);
		
		add(accountLabel);
		accountLabel.setBounds(20,40,50,20);
		add(accountNumber);
		accountNumber.setBounds(80,40,100,20);
		add(passwordLabel);
		passwordLabel.setBounds(10,80,60,20);
		add(accountPassword);
		accountPassword.setBounds(80, 80, 100, 20);
		ensure.addActionListener(new EnsureAction());
		add(ensure);
		ensure.setBounds(70,120,60,20);

		this.atm=atm;
	}
}

//ѡ�������
class SelectInterface extends JPanel
{
	private ATM atm;
	private ViewInterface viewInterface;
	private WithdrawInterface withdrawInterface;
	private DepositInterface depositInterface;
	private static final int WIDTH=200;
	private static final int HEIGHT=200;
	private JButton viewButton;
	private JButton	withdrawButton;
	private JButton	depositButton;
	private JButton exitButton;
	
	public void setView(ViewInterface viewInterface){this.viewInterface=viewInterface;}
	public void setWithdraw(WithdrawInterface withdrawInterface){this.withdrawInterface=withdrawInterface;}
	public void setDeposit(DepositInterface depositInterface){this.depositInterface=depositInterface;}
	public SelectInterface(ATM atm)
	{
		this.atm=atm;
		this.setLayout(null);
		setSize(WIDTH,HEIGHT);
		JLabel prompt=new JLabel("��ѡ����Ҫ���еĲ���");
		//��ʼ����ť
		viewButton=new JButton("���");
		withdrawButton=new JButton("ȡ��");
		depositButton=new JButton("���");
		exitButton=new JButton("�뿪");
		
		//�����¼���Ӧ����
		viewButton.addActionListener(new ViewAction());
		withdrawButton.addActionListener(new WithdrawAction());
		depositButton.addActionListener(new DepositAction());
		exitButton.addActionListener(new ExitAction());
		
		//���ӵ������
		add(prompt);
		add(viewButton);
		add(withdrawButton);
		add(depositButton);
		add(exitButton);
		
		//���ð�ť��λ��
		prompt.setBounds(30,0,160,20);
		viewButton.setBounds(20, 40, 60, 20);
		withdrawButton.setBounds(100,40,60,20);
		depositButton.setBounds(20, 80, 60, 20);
		exitButton.setBounds(100,80,60,20);
	}
	//�鿴��ť��Ӧ����
	private class ViewAction extends AbstractAction
	{

		@Override
		public void actionPerformed(ActionEvent e)
		{
			viewInterface.Refresh();
			SelectInterface.this.setVisible(false);
			viewInterface.setVisible(true);
		}
		
	}
	//ȡ�ť��Ӧ����
	private class WithdrawAction extends AbstractAction
	{

		@Override
		public void actionPerformed(ActionEvent e)
		{
			SelectInterface.this.setVisible(false);
			withdrawInterface.setVisible(true);
		}
		
	}
	//��ť��Ӧ����
	private class DepositAction extends AbstractAction
	{

		@Override
		public void actionPerformed(ActionEvent e)
		{
			SelectInterface.this.setVisible(false);
			depositInterface.setVisible(true);
		}
		
	}
	//�뿪��ť��Ӧ����
	private class ExitAction extends AbstractAction
	{

		@Override
		public void actionPerformed(ActionEvent e)
		{
			//SelectInterface.this.setVisible(false);
			System.exit(0);
		}
			
	}
}

//��ѯ������
class ViewInterface extends JPanel
{
	private ATM atm;
	
	private static final int WIDTH=200;
	private static final int HEIGHT=200;
	private JButton back;
	private String availableBalance;
	private String totalBalance;
	private JLabel availableLabel;
	private JLabel totalLabel;
	
	private SelectInterface selectInterface;
	public void setSelect(SelectInterface selectInterface){this.selectInterface=selectInterface;}
	public void Refresh()
	{
		availableBalance=String.valueOf(atm.getBankDatabase().getAvailableBalance(atm.getAccountNumber()));//atm.getAccountNumber()
		totalBalance=String.valueOf(atm.getBankDatabase().getTotalBalance(atm.getAccountNumber()));
		availableLabel.setText("�˻��������Ϊ��"+availableBalance);
		totalLabel.setText("�˻������Ϊ��"+totalBalance);
	};
	private class BackAction extends AbstractAction
	{

		@Override
		public void actionPerformed(ActionEvent e)
		{
			ViewInterface.this.setVisible(false);
			selectInterface.setVisible(true);
		}
		
	}
	public ViewInterface(ATM atm)
	{	
		this.setLayout(null);
		setSize(WIDTH,HEIGHT);
		this.atm=atm;
		availableBalance=String.valueOf(atm.getBankDatabase().getAvailableBalance(12345));//atm.getAccountNumber()
		totalBalance=String.valueOf(atm.getBankDatabase().getAvailableBalance(12345));
		availableLabel=new JLabel("�˻��������Ϊ��"+availableBalance);
		totalLabel=new JLabel("�˻������Ϊ��"+totalBalance);
		back=new JButton("������һ��");
		
		back.addActionListener(new BackAction());
		
		add(availableLabel);
		add(totalLabel);
		add(back);
		
		availableLabel.setBounds(20,40,180,20);
		totalLabel.setBounds(20,70,180,20);
		back.setBounds(40,100,100,20);
		
	}
}

//ȡ�����
class WithdrawInterface extends JPanel
{
	private ATM atm;
	private static final int WIDTH=200;
	private static final int HEIGHT=200;
	private JButton back;
	private JButton withdraw20;
	private JButton withdraw40;
	private JButton withdraw60;
	private JButton withdraw100;
	
	private SelectInterface selectInterface;
	public void setSelect(SelectInterface selectInterface){this.selectInterface=selectInterface;}
	
	private class BackAction extends AbstractAction
	{

		@Override
		public void actionPerformed(ActionEvent e)
		{
			WithdrawInterface.this.setVisible(false);
			selectInterface.setVisible(true);
		}
		
	}
	
	private class WithdrawAction extends AbstractAction
	{
		private int amount;
		public WithdrawAction(int amount){this.amount=amount;};
		@Override
		public void actionPerformed(ActionEvent e)
		{
			atm.performTransactions(2,amount);
		}
		
	}
	public WithdrawInterface(ATM atm)
	{	
		//��ʼ��
		this.setLayout(null);
		setSize(WIDTH,HEIGHT);
		this.atm=atm;
		back=new JButton("������һ��");
		withdraw20=new JButton("20");
		withdraw40=new JButton("40");
		withdraw60=new JButton("60");
		withdraw100=new JButton("100");
		JLabel prompt=new JLabel("ȡ��");
		
		//�����¼���Ӧ����
		back.addActionListener(new BackAction());
		withdraw20.addActionListener(new WithdrawAction(20));
		withdraw40.addActionListener(new WithdrawAction(40));
		withdraw60.addActionListener(new WithdrawAction(60));
		withdraw100.addActionListener(new WithdrawAction(100));
		
		//���ӵ������
		add(back);
		add(withdraw20);
		add(withdraw40);
		add(withdraw60);
		add(withdraw100);
		add(prompt);
		
		//�������λ��
		prompt.setBounds(80,0,50,20);
		withdraw20.setBounds(20, 40, 60, 20);
		withdraw40.setBounds(100,40,60,20);
		withdraw60.setBounds(20, 80, 60, 20);
		withdraw100.setBounds(100,80,60,20);
		back.setBounds(40,110,100,20);
		
	}
}
class DepositInterface extends JPanel
{
	private ATM atm;
	private static final int WIDTH=200;
	private static final int HEIGHT=200;
	private JButton back;
	private JButton deposit20;
	private JButton deposit40;
	private JButton deposit60;
	private JButton deposit100;
	
	private SelectInterface selectInterface;
	public void setSelect(SelectInterface selectInterface){this.selectInterface=selectInterface;}
	
	private class BackAction extends AbstractAction
	{

		@Override
		public void actionPerformed(ActionEvent e)
		{
			DepositInterface.this.setVisible(false);
			selectInterface.setVisible(true);
		}
		
	}
	
	private class DepositAction extends AbstractAction
	{
		private int amount;
		public DepositAction(int amount){this.amount=amount;};
		@Override
		public void actionPerformed(ActionEvent e)
		{
			atm.performTransactions(3,amount);
		}
		
	}
	public DepositInterface(ATM atm)
	{	
		//��ʼ��
		this.setLayout(null);
		setSize(WIDTH,HEIGHT);
		this.atm=atm;
		back=new JButton("������һ��");
		deposit20=new JButton("20");
		deposit40=new JButton("40");
		deposit60=new JButton("60");
		deposit100=new JButton("100");
		JLabel prompt=new JLabel("���");
		
		//�����¼���Ӧ����
		back.addActionListener(new BackAction());
		deposit20.addActionListener(new DepositAction(20));
		deposit40.addActionListener(new DepositAction(40));
		deposit60.addActionListener(new DepositAction(60));
		deposit100.addActionListener(new DepositAction(100));
		
		//���ӵ������
		add(back);
		add(deposit20);
		add(deposit40);
		add(deposit60);
		add(deposit100);
		add(prompt);
		
		//�������λ��
		prompt.setBounds(80,0,50,20);
		deposit20.setBounds(20, 40, 60, 20);
		deposit40.setBounds(100,40,60,20);
		deposit60.setBounds(20, 80, 60, 20);
		deposit100.setBounds(100,80,60,20);
		back.setBounds(40,110,100,20);
		
	}
}
