import java.awt.AWTException;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Robot;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextPane;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;

public class GUI extends JFrame {
	private JPanel contentPane;
    private PrintStream ps;
    String input;
    boolean ip=false;
    public ATM atm;
    public Robot robot;
	/**
	 * Launch the application.
	 * @throws AWTException 
	 * @throws IOException 
	 */
    public static void main(String[] args) throws AWTException, IOException {
					GUI gui=new GUI();
					gui.setVisible(true);
					gui.atm.run();
	}
	/**
	 * Create the frame.
	 * @throws AWTException 
	 * @throws IOException 
	 */
	public GUI() throws AWTException, IOException {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 520, 451);
		atm=new ATM();
		File file =new File("temp.txt");
		System.setIn(new FileInputStream("temp.txt"));
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 10, 484, 168);
		contentPane.add(scrollPane);
		JTextArea txtrScreen = new JTextArea();
		scrollPane.setViewportView(txtrScreen);
		txtrScreen.setEditable(false);
		 ps = new PrintStream(System.out){
		      public void println(String x) {
		        txtrScreen.append(x + "\n");
		        txtrScreen.setCaretPosition(txtrScreen.getText().length());
		      }
		      public void print(String x){
		    	  txtrScreen.append(x);
		      txtrScreen.setCaretPosition(txtrScreen.getText().length());}
		      
		      public void print(double x){
		    	  txtrScreen.append(String.valueOf(x));
		      txtrScreen.setCaretPosition(txtrScreen.getText().length());}
		      };
		      System.setOut(ps);
		JButton btnNewButton = new JButton("1");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(ip==false){
					input="1";
					ip=true;
					 txtrScreen.append("1");
					return;
				}
				if(ip==true){
					input=input+"1";
				}
				 txtrScreen.append("1");
			}
		});
		btnNewButton.setBounds(10, 188, 42, 36);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("2");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ip==false){
					input="2";
					ip=true;
				}
				if(ip==true){
					input=input+"2";
				}
				 txtrScreen.append("2");
				
			}
		});
		btnNewButton_1.setBounds(64, 188, 42, 36);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("3");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ip==false){
					input="3";
					ip=true;
				}
				if(ip==true){
					input=input+"3";
				}
				 txtrScreen.append("3");
				
			}
		});
		btnNewButton_2.setBounds(116, 188, 42, 36);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("4");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ip==false){
					input="4";
					ip=true;
				}
				if(ip==true){
					input=input+"4";
				}
				 txtrScreen.append("4");
				
			}
		});
		btnNewButton_3.setBounds(10, 236, 42, 36);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("5");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ip==false){
					input="5";
					ip=true;
				}
				if(ip==true){
					input=input+"5";
				}
				 txtrScreen.append("5");
				
			}
		});
		btnNewButton_4.setBounds(65, 234, 42, 38);
		contentPane.add(btnNewButton_4);
		
		JButton button = new JButton("6");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ip==false){
					input="6";
					ip=true;
				}
				if(ip==true){
					input=input+"6";
				}
				 txtrScreen.append("6");
			}
		});
		button.setBounds(116, 234, 42, 38);
		contentPane.add(button);
		
		JButton button_1 = new JButton("7");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ip==false){
					input="7";
					ip=true;
				}
				if(ip==true){
					input=input+"7";
				}
				 txtrScreen.append("7");
			}
		});
		button_1.setBounds(10, 282, 42, 38);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("8");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ip==false){
					input="8";
					ip=true;
				}
				if(ip==true){
					input=input+"8";
				}
				 txtrScreen.append("8");
			}
		});
		button_2.setBounds(64, 282, 42, 38);
		contentPane.add(button_2);
		
		JButton button_3 = new JButton("9");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ip==false){
					input="9";
					ip=true;
				}
				if(ip==true){
					input=input+"9";
				}
				 txtrScreen.append("9");
			}
		});
		button_3.setBounds(116, 282, 42, 38);
		contentPane.add(button_3);
		
		JButton button_4 = new JButton("0");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ip==false){
					input="0";
					ip=true;
				}
				if(ip==true){
					input=input+"0";
				}
				 txtrScreen.append("0");
			}
		});
		button_4.setBounds(10, 330, 42, 38);
		contentPane.add(button_4);
		
		JButton btnEnter = new JButton("ENTER");
		btnEnter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					atm.keypad.num=Integer.parseInt(input);
					atm.keypad.b=true;
					input="";
			}
		});
		btnEnter.setBounds(74, 330, 83, 38);
		contentPane.add(btnEnter);
		
		JTextArea txtrTakeCashHere = new JTextArea();
		txtrTakeCashHere.setText("take cash here");
		txtrTakeCashHere.setBounds(207, 195, 267, 47);
		txtrTakeCashHere.setEditable(false);
		contentPane.add(txtrTakeCashHere);
		
		JTextArea txtrInsert = new JTextArea();
		txtrInsert.setText("insert  deposit envelope here");
		txtrInsert.setBounds(207, 282, 267, 55);
		txtrInsert.setEditable(false);
		contentPane.add(txtrInsert);
	}
}
